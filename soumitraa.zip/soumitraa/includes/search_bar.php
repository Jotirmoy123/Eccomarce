<div class="header-search-bar layout-01">
                            <form action="search_product.php" class="form-search" name="desktop-seacrh" method="get">
                                <input type="text" name="keyword" class="input-text"  placeholder="Search here...">

                                <input type="submit" class="btn-submit" value="search" name="search" style="margin-top: 8px;">
                               
                                <!-- <input type="submit" class="btn-submit"><i class="biolife-icon icon-search"></i></button> -->
                            </form>
                        </div>