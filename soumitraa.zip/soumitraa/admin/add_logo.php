<?php 
    $views = "add_logo";
    include ("template.php");

?>