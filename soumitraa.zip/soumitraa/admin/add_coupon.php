<?php 
    $views = "add_coupon";
    include ("template.php");

?>