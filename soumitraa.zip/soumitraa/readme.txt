1. First create a database name ecommerce in your database. Than import ecommerce.sql file in your ecommerce database.

admin access:
admin@gmail.com
pass:1234


user access:
piyush@gmail.com
123